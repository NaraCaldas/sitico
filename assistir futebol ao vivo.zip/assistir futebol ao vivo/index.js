const express = require('express')
const app = express()
const port = 3000
const bodyparser = require('body-parser')

app.use(bodyparser.urlencoded({extended:false}))
app.use(bodyparser.json())

app.set('view engine','ejs') 

app.use(express.static('public'))

app.get('/', (req , res)=>{
    res.render('index')
})


app.get('/main' , (req,res)=>{
    res.render('page/main')

    
app.get('/espn1',(req , res)=>{
    res.render('page/espn1')
})

})
app.get('/vejamais',(req , res)=>{
    res.render('page/vejamais')
})
app.get('/premiere',(req , res)=>{
    res.render('page/premiere')
})

app.get('/premiere2',(req , res)=>{
    res.render('page/premiere2')
})

app.get('/premiere3',(req , res)=>{
    res.render('page/premiere3')
})

app.get('/premiere4',(req , res)=>{
    res.render('page/premiere4')
})

app.get('/espn2',(req , res)=>{
    res.render('page/espn2')
})

app.get('/espn3',(req , res)=>{
    res.render('page/espn3')
})

app.get('/espn4',(req , res)=>{
    res.render('page/espn4')
})

app.get('/sporttv',(req , res)=>{
    res.render('page/sporttv')
})

app.get('/sporttv2',(req , res)=>{
    res.render('page/sporttv2')
})

app.get('/sporttv3',(req , res)=>{
    res.render('page/sporttv3')
})

app.get('/sporttv4',(req , res)=>{
    res.render('page/sporttv4')
})

app.get('/starplus',(req , res)=>{
    res.render('page/starplus')
})

app.get('/tcpremium',(req , res)=>{
    res.render('page/tcpremium')
})

app.get('/tcaction',(req , res)=>{
    res.render('page/tcaction')
})

app.get('/tctouch',(req , res)=>{
    res.render('page/tctouch')
})

app.get('/tcfun',(req , res)=>{
    res.render('page/tcfun')
})

app.get('/h2',(req , res)=>{
    res.render('page/h2')
})

app.get('/history',(req , res)=>{
    res.render('page/history')
})

app.get('/mtv',(req , res)=>{
    res.render('page/mtv')
})

app.get('/hbo',(req , res)=>{
    res.render('page/hbo')
})

app.get('/megapix',(req , res)=>{
    res.render('page/megapix')
})

app.get('/multishow',(req , res)=>{
    res.render('page/multishow')
})

app.get('/natgeo',(req , res)=>{
    res.render('page/natgeo')
})

app.get('/space',(req , res)=>{
    res.render('page/space')
})

app.get('/universal',(req , res)=>{
    res.render('page/universal')
})

app.get('/warner',(req , res)=>{
    res.render('page/warner')
})

app.get('/cartoon',(req , res)=>{
    res.render('page/cartoon')
})

app.get('/comedycentral',(req , res)=>{
    res.render('page/comedycentral')
})

app.get('/tnt',(req , res)=>{
    res.render('page/tnt')
})

app.get('/paramount',(req , res)=>{
    res.render('page/paramount')
})

app.get('/canalcultura',(req , res)=>{
    res.render('page/canalcultura')
})
app.get('/combate',(req , res)=>{
    res.render('page/combate')
})
app.get('/ufcfightpass',(req , res)=>{
    res.render('page/ufcfightpass')
})
app.get('/tntsports',(req , res)=>{
    res.render('page/tntsports')
})

app.listen(port , ()=>{
    console.log('Servidor Online!')
})