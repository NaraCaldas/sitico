// Lista para armazenar os favoritos
let favorites = JSON.parse(localStorage.getItem('favorites')) || [];

function addToFavorites(channel) {
  if (!favorites.includes(channel)) {
    favorites.push(channel);
    localStorage.setItem('favorites', JSON.stringify(favorites));
    alert(channel + ' foi adicionado aos seus favoritos!');
  } else {
    alert(channel + ' já está nos seus favoritos!');
  }
}
